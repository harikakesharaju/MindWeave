package com.myProjects.mindWeave;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MindWeaveApplicationTests {

	@Test
	void contextLoads() {
	}

}
